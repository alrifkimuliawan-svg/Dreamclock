DreamClock — versi Android (PWA)

ISI
- index.html: aplikasi jam digital
- manifest.webmanifest: konfigurasi untuk dipasang sebagai aplikasi web
- sw.js: cache/offline sederhana

FITUR
- Jam real-time dan tanggal Indonesia
- Pilihan tema wallpaper
- Pilih foto sendiri dari galeri
- Menyimpan wallpaper di browser perangkat
- Tombol format 12/24 jam
- Pesan kecil acak

CARA MEMAKAI DARI HP ANDROID
1. Ekstrak ZIP ini di HP menggunakan aplikasi pengelola file.
2. Agar bisa dipasang sebagai aplikasi, file perlu disajikan melalui situs HTTPS. Membuka index.html langsung dari file manager bisa dipakai untuk mencoba, tetapi biasanya tidak mendukung instalasi PWA.
3. Cara praktis: unggah isi folder ini ke layanan hosting statis HTTPS (misalnya GitHub Pages, jika kamu sudah punya akun), lalu buka alamat situsnya di Chrome Android.
4. Di Chrome, tekan menu ⋮ > "Tambahkan ke layar utama" atau "Install app" jika tersedia.

CATATAN PENTING
- Ini adalah PWA, bukan APK native. Tidak perlu Android Studio untuk memakai versi web-app ini.
- Widget jam native Android belum disertakan. Widget homescreen membutuhkan komponen Android native; PWA tidak bisa membuat widget jam sistem sendiri.
- Untuk mengganti wallpaper, tekan "Foto sendiri" di dalam aplikasi.
- Foto disimpan di penyimpanan lokal browser. Menghapus data browser dapat menghapus pengaturan tersebut.
